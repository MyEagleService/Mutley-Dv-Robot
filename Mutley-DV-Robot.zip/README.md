# Mutley-Dv-Robot
🐶 Mutley foi criado para canais de divulgação!
voce criar o modelo de sua postagem, e ele 
compartilha isso no canal.

# 📚 LEGENDA<Br>
DV = DIVULGAÇÃO / DIVULGAÇÕES<Br>
CN = CANAL / CANAIS<Br>
GP = GRUPO / GRUPOS<Br>
DEV = Developer / Desenvolvedor.<Br>

🟨 A DV será feita no canalque você cadastrar durantea instalação do robot.

🟨 Você poderá fazer a DV assim como todo mundo poderá.
    
🔥 Limite as DV diárias.<Br>
🔥 Relatorio de DV enviados.<Br>
🔥 Defina Links Publicos ou Privados.<Br>
🔥 As DV podem ser avaliadas pelo dono.<Br>
🔥 Config DV Membros e Não membros.<Br>
🔥 Publicações podem ser avaliadas<Br>
🔥 Users insistentes = Advertencia.<Br>

#INSTALAÇÃO<Br>
Tipo de Hospedagem Linux.<Br>
<p> Hospedagem Recomendada
<a href="http://t.me/HarrisonnWells">COMPRE AQUI</a>.
</p>

<p> VPS Recomendada 512MB
<a href="https://www.avirahost.com.br/aff.php?aff=120">COMPRE AQUI</a>.
</p>

##Se não sabe instalar solicite ajuda, isso aqui não é para amadores 

✈️ TELEGRAM<Br>
CN Dev.   http://t.me/MyEagleChannel <Br>
GP Dev.   http://t.me/MyEagleProject <Br>
Perfil DV.  http://t.me/HarrisonnWells <Br>
